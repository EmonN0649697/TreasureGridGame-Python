

def title():
    print(
    """
     _____                                                        _            
    /__   \_ __ ___  __ _ ___ _   _ _ __ ___    /\  /\_   _ _ __ | |_ ___ _ __ 
      / /\| '__/ _ \/ _` / __| | | | '__/ _ \  / /_/ | | | | '_ \| __/ _ | '__|
     / /  | | |  __| (_| \__ | |_| | | |  __/ / __  /| |_| | | | | ||  __| |   
     \/   |_|  \___|\__,_|___/\__,_|_|  \___| \/ /_/  \__,_|_| |_|\__\___|_|
     """
    )
    
def instructions():
    """Display game instructions."""
    
    print(
    """
    Welcome to Treasure Hunter! Your objective here is to find the opponents' treasure before they find yours.
    
    You will take turns to guess where the treasure is hidden
    on a grid like this:

               .----------------------------------.
               |      |      |      |      |      |
               |  A1  |  A2  |  A3  |  A4  |  A5  |
               |      |      |      |      |      |
               |------|------|------|------|------|
               |      |      |      |      |      |
               |  B1  |  B2  |  B3  |  B4  |  B5  |
               |      |      |      |      |      |
               |------|------|------|------|------|
               |      |      |      |      |      |
               |  C1  |  C2  |  C3  |  C4  |  C5  |
               |      |      |      |      |      |
               |------|------|------|------|------|
               |      |      |      |      |      |
               |  D1  |  D2  |  D3  |  D4  |  D5  |
               |      |      |      |      |      |
               |------|------|------|------|------|
               |      |      |      |      |      |
               |  E1  |  E2  |  E3  |  E4  |  E5  |
               |      |      |      |      |      |
               '----------------------------------'

    To guess, simply type the square you think the treasure's in when prompted.

    Like this: "A1"

    REMEMBER: Type in all caps lock whenever you input anything, got it?
    Good luck!
    """
    )


#main

title()
instructions()


import random
moves=0
Square=("A1", "A2", "A3", "A4", "A5", "B1", "B2", "B3", "B4", "B5", "C1", "C2", "C3", "C4", "C5", "D1", "D2", "D3", "D4", "D5", "E1", "E2", "E3", "E4", "E5")

Player = input("What's your name?\n")

text_file = open ("PlayerStats.txt", "w")

cpu_treasure = random.choice(Square)
my_treasure = input("Now, hide your treasure on one of the squares above before you begin by typing in a grid number:\n\n")

guess = input("Where could the opponent's treasure be?:\n")

cpu_guess = random.choice(Square)

while guess != cpu_treasure:
    moves+=1
    print("\t\t\tIt doesn't seem to be in that square.\n")
    print("It's the computer's turn to guess now, and it guessed your treasure to be hidden at", cpu_guess)
    if cpu_guess != my_treasure:
        cpu_guess = random.choice(Square)

        guess = input("\nPhew! It guessed wrong. Now where could the opponent's treasure be?:\n")
     
    if guess == cpu_treasure:
        print("\t\t\tYou've found it! Haha!\n")
        print("Moves", moves)
    if cpu_guess == my_treasure:
        print("\t\t\tOh no, they've found it!")
        break

text_file.write("Player %s" % Player)
text_file.write("- Moves %s" % moves)
text_file.close()

print("Thanks for your efforts, fellow explorer!")
print("\n\nPress enter to exit")



